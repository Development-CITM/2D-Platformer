Artwork created by Luis Zuno (@ansimuz)

License for Everyone. This piece is under a CC-BY-3.0 License http://creativecommons.org/licenses/by/3.0/ You can copy, modify, distribute and perform the work, even for commercial purposes, as long as you give appropiate credit. You are not require to credit this work if you are or had been a Patreon Supporter at https://www.patreon.com/ansimuz

Get more Free Assetslike these at: http://www.pixelgameart.org

